from setuptools import setup, find_packages

setup(name='parametergenerate',
      version="1.0.0",
      description='parameter generate for Ansible',
      author='NEC Corporation',
      url='',
      install_requires=['chardet'],
      maintainer='NEC Corporation',
      packages=['parametergenerate']
)
