# -*- coding: UTF-8 -*-

# action plugins はansible上にパッケージではないですが
# テストのために、パッケージの形でテストができます
